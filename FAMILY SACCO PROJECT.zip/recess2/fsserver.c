#include<stdio.h>
#include<stdlib.h>

#include<sys/types.h>
#include<sys/socket.h>

#include<netinet/in.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
struct recieved{
char command[100];
char user[20];
char pward[50];
};

int main(int argc,char argv[])
{
FILE *tai;
//variables
int sock;
struct sockaddr_in server;
int mysock;
char buff[1024];

struct recieved memberData;
int rval,rval1,rval2;
//create server socket
sock=socket(AF_INET,SOCK_STREAM,0);
if(sock<0){
perror("failed to create socket");
exit(1);
}
//define the server adress
server.sin_family=AF_INET;
server.sin_port=htons(5000);
server.sin_addr.s_addr=INADDR_ANY;

//bind the socket to the specified IP and port
if(bind(sock,(struct sockaddr*) &server,sizeof(server))){
perror("failed to bind socket");
exit(1);
}

//listen for connections
listen(sock,5);


//Accept connections
do{
 mysock=accept(sock,NULL,NULL);
 if(mysock==-1){
   perror("Accept failed");
 }
 else{
  memset(buff,0,sizeof(buff));
  
  //memset(struct memberData,0,sizeof(struct memberData));
  if((rval=recv(mysock,buff,sizeof(buff),0))<0){
    perror("Reading stream message failed");
   }
   else if(rval==0){
   printf("Ending connection\n");
  }
  else{
     if((tai=fopen("sacco.txt","ab"))==NULL){
  printf("File sacco couldn,t be opened");
  }else{
   //fwrite(buff,sizeof(buff),1,tai);
fprintf(tai,"%s\n",buff);
  fclose(tai);
  }
   printf("MSG: %s\n",buff);
   printf("Got message (rval=%d)\n",rval);
  //close socket
  close(mysock);
  }
}
}while(1);
return 0;
}

