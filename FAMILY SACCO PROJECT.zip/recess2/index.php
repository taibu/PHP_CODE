
<!DOCTYPE html>
<html>

<head>
<link rel='stylesheet' href='casc.css'>
<style type="text/css">
</style>
<script src="lfamilysaco.js"></script>
</head>
<body>


<div id="log">
<form action="fsfunctions.php" method="post" id="formi">
<h1>FAMILY SACCO LOGIN PAGE</h1>
<fieldset>
<legend><b>Login</b></legend>
<table border="0" cellspacing="15" id="itable">
<tr>
<td>User name:</td>
<td><input type="text" name="username" required></td>
<td><input type="radio" name="logtype" id="admin" value="admin" required>Administrator.</td>
</tr>
<tr>
<td>Password:</td>
<td><input type="password" name="password" required></td>
<td><input type="radio" name="logtype" value="memebr">Member.</td>
</tr>
<tr>
<td></td><td></td>
<td><input type="submit" value="login" id="sub" ></td>
</tr>
</table>
</fieldset>
<p class="loghelp"><a href="index.php" >Forgot username or password</a>
</form>
</body>
</html>
<?php
/*require_once('fsfunctions.php');
if(!isset($_POST['username'])){*/
session_start();
$_SESSION['valid_user']="taibu";
/*if(isset($_SESSION['valid_user'])){
unset($_SESSION['valid_user']);
session_destroy();
echo "session destroyed";
}
}*/
?>