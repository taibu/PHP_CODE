#include<stdio.h>
#include<stdlib.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<unistd.h>
//#define DATA "Welcome to FAMILY SACCO"


struct clientData{
char msg[100];
char user[20];
char pword[50];
};

int main(int argc,char *argv[])
{

//create the server socket
int sock;
struct sockaddr_in server;
struct hostent *hp;//*gethostbyname();
//char buff[1024];
char message[1024];

sock=socket(AF_INET,SOCK_STREAM,0);
if(sock<0){
perror("failed to create socket");
exit(1);
}

server.sin_family=AF_INET;
hp=gethostbyname(argv[1]);
if(hp==0){
perror("failed to get host by name");
exit(1);
}
memcpy(&server.sin_addr,hp->h_addr,hp->h_length);
server.sin_port=htons(5000);

if(connect(sock,(struct sockaddr *)&server,sizeof(server))<0){
perror("failed to connect");
exit(1);
}
//output a menu for the user
printf("\n***************MENU*****************\n1-contribution amount date name reciept_number\n"
        "2-contribution check\n3-benefits check\n4-loan repayment_details\n"
        "5-loan request_amount\n6-idea name capital description\n7-loan status\n"
         "*************************************************\n");
//Get user option
fgets(message,sizeof(message),stdin);
if(message!=0){
/*fgets(member.msg,sizeof(member.msg),stdin);
if(strncmp(member.msg,"loan status",4)==0){
//Request for member username and password
printf("Enter Your username and password to check the loan status\n");
printf("Username:");
scanf("%s",&member.user);
printf("Password:");
scanf("%s",&member.pword);
}*/
if((strncmp(message,"contribution",12)==0) && (strncmp(message,"contribution check ",15)!=0)){
if(strlen(message)>35){
  send(sock,message,sizeof(message),0);
printf("Your data has been sent\n");
 }else{
   printf("Please enter a valid command\n");
 }
} 
else{
manipulateUserOption(message);

}
/*if(send(sock,message,sizeof(message),0)<0)

{
perror("failed to send");
exit(1);

}
else{
printf("Please wait as your request is being processed....\n");
 close(sock);
}*/
}
return 0;

}
void manipulateUserOption(char message[]){
char user[40],pword[50];
if(strncmp(message,"contribution check",18)==0){
  if(strlen(message)==19){
 printf("Enter Your username and password to check your contributions\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
  }else{
   printf("Please enter a valid command\n");
  }
}
if(strncmp(message,"benefits check",14)==0){
  if(strlen(message)==15){
 printf("Enter Your username and password to check your benefits\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
  }else{
   printf("Please enter a valid command\n");
  }
}
if(strncmp(message,"loan status",11)==0){
  if(strlen(message)==12){
 printf("Enter Your username and password to check your loan status\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
  }else{
   printf("Please enter a valid command\n");
  }
}
if(strncmp(message,"loan repayment_details",20)==0){
  if(strlen(message)==23){
 printf("Enter Your username and password to check your loan repayment details\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
  }else{
   printf("Please enter a valid command\n");
}

}
if(strncmp(message,"loan request",12)==0){
  if(strlen(message)>18){
 printf("Enter Your username and password to submit your loan request\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
  }else{
   printf("Please enter a valid command\n");
}

}

if(strncmp(message,"idea",4)==0){
if(strlen(message)>10){
  printf("Enter Your username and password to submit idea\n");
printf("Username:");
scanf("%s",&user);
printf("Password:");
scanf("%s",&pword);
}
else{
printf("Please enter a valid command\n");
}
}

}

