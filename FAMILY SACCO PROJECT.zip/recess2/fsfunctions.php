<?php
echo "<link rel='stylesheet' href='casc.css'>";
//Establiss connection
$con=mysql_connect("localhost","root","");
createDataBase();
$db = new mysqli('localhost', 'root','','familysacco');
//Check connection
if(!$con){
die("Un able to connect to the server".mysql_error());
}
//select database
 mysql_select_db("familysacco");
 
 if(isset($_POST['logtype'])){
homepage();
}
 if(isset($_POST['searchtype'])){
if($_POST['searchtype']=="invest"){
followup();
}
if($_POST['searchtype']=="new"){
Addmember();
}
if($_POST['searchtype']=="newidea"){
newidea();
}

if($_POST['searchtype']=="verifycontributions"){
verify();
}
if($_POST['searchtype']=="verifyloan"){
verifyloan();
}
if($_POST['searchtype']=="verifyidea"){
verifyideas();
}
if($_POST['searchtype']=="loans"){
reports();
}
if($_POST['searchtype']=="payback"){
reports();
}
if($_POST['searchtype']=="benefits"){
echo "benefit details";
reports();
}				
if($_POST['searchtype']=="members"){
reports();
}
if($_POST['searchtype']=="contributions"){
reports();
}
if($_POST['searchtype']=="investment"){
reports();
}
}
if(isset($_POST['memberusername'])){
submitmember();
}
if(isset($_POST['followUpamount'])){
submitfollow();
}
if(isset($_POST['capital'])){
submitnewidea();
}

/*This function is used by to display a form for the administrator to submit new 
member details to the database*/
function Addmember(){
session_start();
$_SESSION['valid_user']="Taibu";
echo "<div id='bdy'>";
echo "<p id='start' ><b>ADD NEW MEMBER</b></p>";
echo "<form action='fsfunctions.php' method='POST'>";
echo "<fieldset>";
echo "<legend id='legend1'><b>MEMBER DETAILS</b></legend>";
echo "<table border='0' id='table1' cellspacing='50' align='CENTER'>";
echo "<tr>";
echo "<td>Member Name</td><td><input type='text'  id='demo1' name = 'membername' required></td>";
echo "<tr>";
echo "<td>Username</td><td><input type='text' id='demo1' name = 'memberusername' required></td>";
echo "</tr>";
echo "<tr>";
echo "<td>Password</td><td><input type='text'id='demo1' name = 'memberpassword' required></td>";
echo "</tr>";
echo "</table>";
echo "<p id='btons'><input type='submit' value='Submit' ><input type='reset' value='Cancel'></p>";
echo "</fieldset>";
echo "</form>";
echo "</div>";
}

/* This function reads data from the server file and displays it in the browser*/
function verify(){
session_start();
$_SESSION['valid_user']="Taibu";
if(!fopen('sacco.txt','r+')){
echo "file couldn't be opened";
}else{
echo "<div id='contr'>";
echo "<h3  id='hd'>FAMILY SACCO PENDING CONTRIBUTIONS</H3>";
echo "<ul id='verif'>";
$lines= file('sacco.txt');
foreach($lines as $data){
if((strncmp($data,"contribution",12)==0)){
$details=explode(" ",$data);
$name=$details[3]." ".$details[4];
echo "<form action='fsfunctions.php' method='POST' >";
echo "<li>$details[1] $details[2] $name $details[5]</li>";
echo "<select name='subcont'>";
echo "<option value='accept'>Accept</option>";
echo "<option value='reject'>reject</option>";
echo "</select>";
echo "<input type='hidden' name='myname' value='$name'>";
echo "<input type='submit' name='subm' value='OK'>";
 }
//file_put_contents('sacco.txt', str_replace($data, " ", file_get_contents('sacco.txt')));
}
}
echo "</ul>";
echo "</div>";
}


/*This function executes when the administrator choses to approve investment ideas submited
by the members*/
function verifyideas(){
session_start();
$_SESSION['valid_user']="Taibu";
if(!fopen('sacco.txt','r+')){
echo "file couldn't be opened";
}else{
echo "<div id='contr'>";
echo "<h3  id='hd'>FAMILY SACCO PENDING INVESTMENT IDEAS</h3>";
echo "<ul id='verif'>";
$lines= file('sacco.txt');
foreach($lines as $data){
if((strncmp($data,"idea",3)==0)){
$details=explode(" ",$data);
echo "<li>$details[1] $details[2] $details[3]</li>";

//file_put_contents('sacco.txt', str_replace($data, " ", file_get_contents('sacco.txt')));
}
}
echo "</ul>";
echo "</div>";
}
}

/*This function executes when the administrator choose to approve loan requests 
submitted by members*/
function verifyloan(){
session_start();
$_SESSION['valid_user']="Taibu";
if(!fopen('sacco.txt','r+')){
echo "file couldn't be opened";
}else{
echo "<div id='contr'>";
echo "<h3  id='hd'>FAMILY SACCO PENDING LOANS</H3>";
echo "<ul id='verif'>";
$lines= file('sacco.txt');
foreach($lines as $data){
if((strncmp($data,"loan",4)==0)){
$details=explode(" ",$data);
$name=$details[3]." ".$details[4];
echo "<form action='fsfunctions.php' method='POST' >";
echo "<li>$details[1] $details[2] $name $details[5]</li>";
//file_put_contents('sacco.txt', str_replace($data, " ", file_get_contents('sacco.txt')));
}
}
echo "</ul>";
echo "</div>";
 }
}

/*This function is used to display a form for the administrator to 
submit profits or losses details to the database*/
function followup(){
session_start();
$_SESSION['valid_user']="Taibu";
echo "<div id='bdy'>";
echo "<p id='start' ><b>SUBMIT FOLLOWUP RESULTS</b></p>";
echo "<form action='fsfunctions.php' method='POST'>";
echo "<fieldset>";
echo "<legend id='legend1'><b>INCOME STATEMENT DETAILS</b></legend>";
echo "<table border='0' id='table1' cellspacing='50' align='CENTER'>";
echo "<tr>";
echo "<td>Idea ID</td><td><input type='text'  id='demo1' name = 'idea' required></td>";
echo "<tr>";
echo "<td>Amount</td><td><input type='text' id='demo1' name = 'followUpamount' required></td>";
echo "</tr>";
echo "<tr>";
echo "<td>Category</td><td><select id='sect' name = 'category' required>";
echo"<option>Profit</option>";
echo"<option>Loss</option>";
echo"</select>";
echo "</td>";
echo "</tr>";
echo "</table>";
echo "<p id='btons'><input type='submit' value='Submit' ><input type='reset' value='Cancel'></p>";
echo "</fieldset>";
echo "</form>";
echo "</div>";
}
function newidea(){
session_start();
$_SESSION['valid_user']="Taibu";
echo "<div id='bdy'>";
echo "<p id='start' ><b>ENTER NEW INVESTMENT IDEA DETAILS</b></p>";
echo "<form action='fsfunctions.php' method='POST'>";
echo "<fieldset>";
echo "<legend id='legend1'><b>IDEA DETAILS</b></legend>";
echo "<table border='0' id='table1' cellspacing='50' align='CENTER'>";
echo "<tr>";
echo "<td>Idea Name</td><td><input type='text'  id='demo1' name = 'ideaname' required></td>";
echo "</tr>";
echo "<tr>
<td>Description</td><td><input type='text'  id='demo1' name = 'description' required></td>";
echo "</tr>";
echo "<tr>
<td>Suggested by</td><td><input type='text'  id='demo1' name = 'membername' required></td>";
echo "</tr>";
echo "<td>Initial Investment Price</td><td><input type='text' id='demo1' name = 'capital' required></td>";
echo "</tr>";
echo "</table>";
echo "<p id='btons'><input type='submit' value='Submit' ><input type='reset' value='Cancel'></p>";
echo "</fieldset>";
echo "</form>";
echo "</div>";
}
/*Function reports is used to output a report.It works for all reports and it uses the 
if statements to determine which report to output based on the user selection */
function reports(){
       session_start();
       $_SESSION['valid_user']="Taibu";
      //If user selected loans report.
		if($_POST['searchtype']== "loans"){
		$db = new mysqli('localhost', 'root','','familysacco');
            $qury = "select * from loans" ;
			$result = $db->query($qury);
        //asign the number of rows selected to the variable.
			$num = $result->num_rows;
			//output the selected data in table format*/
	     echo "<div id='table'>";
		 echo "<table border='1'>";
		 echo "<tr>";
		 echo "<td colspan='7' style='text-align:center'>"."LOAN DETAILS"."</td>";
		 echo "</tr>";
		 echo "<tr id='ni'>";
		 echo "<td>Loan No.</td>";
		 echo "<td>Loan Amount</td>";
		 echo "<td>Loan_Date</td>";
		 echo "<td>Monthly Repay</td>";
		 echo "<td>Total Payback</td>";
		 echo "<td>Repayment_date</td>";
		 echo "</tr>";
			for($j=0;$j<$num;++$j){
				$row = $result->fetch_assoc();
					echo "<tr>";
					echo "<td>".$row['loan_no']."</td>";
					echo "<td>".$row['loan_amount']."</td>";
					echo "<td>".$row['loan_date']."</td>";
					echo "<td>".$row['monthly_repay']."</td>";
					echo "<td>".$row['total_repayment']."</td>";
					echo "<td>".$row['repayment_date']."</td>";
					echo "</tr>";
					}
					echo "</table>";
					echo"</div>";
				}
				//If user selected loan payback reports
				if($_POST['searchtype']== "payback"){
				echo "<div id='table'>";
				echo "<table border='1'>";
				echo "<tr>";
				echo "<td colspan='7' style='text-align:center'>"."LOAN PAYBACK DETAILS"."</td>";
				echo "</tr>";
				echo "<tr id='ni'>";
				echo "<td>Loan No.</td>";
				echo "<td>Pay_date</td>";
				echo "<td>Amount</td>";
				echo "<td>Total Paidback</td>";
				echo "<td>Percentage</td>";
				echo "</tr>";
				echo "</table>";
				echo"</div>";
			}
			//If user selected Family sacco members report
			if($_POST['searchtype']== "members"){
	       $db = new mysqli('localhost', 'root','','familysacco');
            $qury = "select * from members" ;
			$result = $db->query($qury);
        //asign the number of rows selected to the variable.
			$num = $result->num_rows;
			//output the selected data in table format*/
			    echo "<div id='table'>";
				echo "<table border='0'>";
				echo "<tr id='head'>";
				echo "<td colspan='3' style='text-align:center'>"."FAMILY SACCO MEMBERS LIST"."</td>";
				echo "</tr>";
				echo "<tr id='colh'>";
				echo "<td>Name.</td>";
				echo "<td>User name</td>";
				echo "<td>Date joined</td>";
				echo "</tr>";
				for($j=0;$j<$num;++$j){
					$row = $result->fetch_assoc();
					if($j%2==0){
					echo "<tr id='even'>";
					echo "<td>".$row['name']."</td>";
					echo "<td>".$row['user_name']."</td>";
					echo "<td>".$row['date_joined']."</td>";
					echo "</tr>";
					}
					else{
					echo "<tr id='odd'>";
					echo "<td>".$row['name']."</td>";
					echo "<td>".$row['user_name']."</td>";
					echo "<td>".$row['date_joined']."</td>";
					echo "</tr>";
					}

				}
				echo "</table>";
				echo"</div>";
}
			
			
			//Report showing details of investment ideas.
			if($_POST['searchtype']== "investment"){
	       $db = new mysqli('localhost', 'root','','familysacco');
            $qury = "select * from investment_ideas" ;
			$result = $db->query($qury);
        //asign the number of rows selected to the variable.
			$num = $result->num_rows;
			//output the selected data in table format*/
			    echo "<div id='table'>";
				echo "<table border='0'>";
				echo "<tr id='head'>";
				echo "<td colspan='5' style='text-align:center'>"."FAMILY SACCO IVESTMENT IDEAS"."</td>";
				echo "</tr>";
				echo "<tr id='colh'>";
				echo "<td>Idea ID.</td>";
				echo "<td>Idea name</td>";
				echo "<td>Description</td>";
				echo "<td>Date Started</td>";
				echo "<td>Initial Capital</td>";
				echo "</tr>";
				for($j=0;$j<$num;++$j){
					$row = $result->fetch_assoc();
					if($j%2==0){
					echo "<tr id='even'>";
					echo "<td>".$row['idea_id']."</td>";
					echo "<td>".$row['idea_name']."</td>";
					echo "<td>".$row['description']."</td>";
					echo "<td>".$row['date_started']."</td>";
					echo "<td>".$row['capital']."</td>";
					echo "</tr>";
					}
					else{
					echo "<tr id='odd'>";
					echo "<td>".$row['idea_id']."</td>";
					echo "<td>".$row['idea_name']."</td>";
					echo "<td>".$row['description']."</td>";
					echo "<td>".$row['date_started']."</td>";
					echo "<td>".$row['capital']."</td>";
					echo "</tr>";
					}

				}
				echo "</table>";
				echo"</div>";
			}
			
			
			
			//Report showing members contributions and shares
			if($_POST['searchtype']== "contributions"){
	       $db = new mysqli('localhost', 'root','','familysacco');
            $qury = "select * from shares" ;
			$result = $db->query($qury);
        //asign the number of rows selected to the variable.
			$num = $result->num_rows;
			//output the selected data in table format*/
			    echo "<div id='table'>";
				echo "<table border='0'>";
				echo "<tr id='head'>";
				echo "<td colspan='3' style='text-align:center'>"."FAMILY SACCO MEMBERS CONTRIBUTIONS AND SHARES"."</td>";
				echo "</tr>";
				echo "<tr id='colh'>";
				echo "<td>User Name</td>";
				echo "<td>Contributions</td>";
				echo "<td>Total Shares</td>";
				echo "</tr>";
				for($j=0;$j<$num;++$j){
					$row = $result->fetch_assoc();
					if($j%2==0){
					echo "<tr id='even'>";
					echo "<td>".$row['username']."</td>";
					echo "<td>".$row['share_percentage']."</td>";
					echo "<td>".$row['total_contribution']."</td>";
					echo "</tr>";
					}
					else{
					echo "<td>".$row['username']."</td>";
					echo "<td>".$row['share_percentage']."</td>";
					echo "<td>".$row['total_contribution']."</td>";
					echo "</tr>";
					}

				}
				echo "</table>";
				echo"</div>";
			}

	}	
	/*This function submits members details to the database*/ 	
	function submitmember(){
	session_start();
    $_SESSION['valid_user']="Taibu";
	$username=$_POST['memberusername'];
	$name=$_POST['membername'];
	$pword=$_POST['memberpassword'];
	$date=date('jS:F:Y');
	//echo "$date";
	/*Insert the user input data into table student it alert the member
	if the data is submitted or not*/
	if(mysql_query("INSERT INTO members
	VALUES('$username','$name','$pword','$date')"))
	{
	//If data submited to the table alert the user.
	mysql_query("INSERT INTO shares
	          VALUES('$username',0.0,0)");
	   echo "<script>alert('Member added succesfully')</script>";
	   Addmember();
	}
	  else{
	//If data not submited to the table alert the user.
	   echo "<script>alert('Data not submitted. Please check the data and try again')</script>";
	   Addmember();
	 }
	}
	
	  //This function submit new investment idea information to the database
  function submitnewidea(){
   session_start();
   $_SESSION['valid_user']="Taibu";
	$idea=$_POST['ideaname'];
	$desc=$_POST['description'];
	$membername=$_POST['membername'];
	$capital=$_POST['capital'];
	$date=date('jS:F:Y');
	
	//echo "$date";
	/*Insert the user input data into table student it alert the member
	if the data is submitted or not*/
	if(mysql_query("INSERT INTO investment_ideas
	VALUES(NULL,'$idea','$desc','$capital','$date','$membername')"))
	{
	//If data submited to the table alert the user.
	   echo "<script>alert('Data submitted succesfully')</script>";
	   newidea();
	}  
	  else{
	//If data not submited to the table alert the user.
	   echo "<script>alert('Data not submitted. Please check the data and try again')</script>";
	   newidea();
	 }
	 }
	
	
	  //This function submit profits orr loss information to the database
  function submitfollow(){
	$idea=$_POST['idea'];
	$amount=$_POST['followUpamount'];
	$category=$_POST['category'];
	$date=date('jS:F:Y');
	//echo "$date";
	/*Insert the user input data into table student it alert the member
	if the data is submitted or not*/
	if(mysql_query("INSERT INTO investment_followUp
	VALUES('$idea','$date','$amount','$category')"))
	{
	//If data submited to the table alert the user.
	   echo "<script>alert('Data submitted succesfully')</script>";
	   followup();
	}
	  else{
	//If data not submited to the table alert the user.
	   echo "<script>alert('Data not submitted. Please check the data and try again')</script>";
	   followup();
	 }
	 }
	function homepage(){
$connect=mysqli_connect("localhost","root","","familysacco");
/*The if statement checks whether a person logged in an administrator or a member in order to 
provide the relevant manipulation privileges*/
$type=$_POST['logtype'];
echo "<DIV ID='bdyy'>";
if($type=="admin"){
$uname=$_POST['username'];
$pword=$_POST['password'];
$result="SELECT *FROM admin
         WHERE username='$uname' AND password='$pword'";
$log=$connect->query($result);
if($log->fetch_assoc()==NULL){
	   	//If administrators login information is not valid
	   echo "<script>alert('Username and password not matching.'+' Please enter correct username and password')</script>";
	   echo "<script>window.open('index.php','_self')</script>";
	}
				
echo "<article id='back'>";	
echo "<p class='logout'><a href='index.php'>logout($uname)</a></p>";
echo "<p class='img1'><img src='fSlogo.png' alt='No image found' width='100px'></p>";
echo "<br/>";
echo "<br/>";

//Heading of the home page
echo "<h1>FAMILY SACCO HOME PAGE</h1>";
echo "</article>";
echo "<div align='center' class='lk' name='top' id='topp'>";
echo "</div>";

/*Division contains a selection drop down which enable the administrator to  chose 
an option depending on the data he/she wants to save to the database*/
echo "<div id='input'>";
    echo "<h3>SELECT OPTION TO SUBMIT DATA:</h3>";
      echo "<form action='fsfunctions.php' method='post'>";
			//Choose Search Type(Click on the drop down to select a table to be displayed)
		echo "<select name ='searchtype'>";
		echo "<option value='new'>Add Member</option>";
		echo "<option value='invest'>Investment Details</option>";
		echo "<option value='verifycontributions'>Verify Contributions</option>";
		echo "<option value='verifyloan'>Approve loan Requests</option>";
		echo "<option value='newidea'>Enter new Idea details</option>";
		echo "<option value='verifyidea'>Ideas suggestions</option>";
		echo "</select>";
		echo "<input type='submit' value='Continue'>";
	 echo "</form>";
echo "</div>";	
}else{
$uname=$_POST['username'];
$pword=$_POST['password'];
$result="SELECT user_name,password FROM members
         WHERE user_name='$uname' AND password='$pword'";
$log=$connect->query($result);
if($log->fetch_assoc()==NULL){
	   	//If administrators login information is not valid
	   echo "<script>alert('Username and password not matching.'+' Please enter correct username and password')</script>";
	   echo "<script>window.open('index.php','_self')</script>";
	}
echo "<div id='back'>";
echo "<p class='logout'><a href='index.php'>logout($uname)</a></p>";
echo "<p class='img1'><img src='fSlogo.png' alt='No image found' width='100px'></p>";
echo "<br/>";
echo "<br/>";
echo "<h1>FAMILY SACCO HOME PAGE</h1>";
echo "</div>";
echo "<div align='center' class='lk' name='top' id='topp'>";
echo "</div>";
}
echo "<br/>";

/*This section contains a form that displays a list of check boxes for 
a user(member or administrator) to select the report they want view*/

echo "<section id='side'>";
echo "<form action='fsfunctions.php' method='post'>";
echo "<fieldset id='set'>";
echo "<legend id='leg'><b>FAMILY SACCO REPORTS</b></legend>";
echo "<ul>";
echo "<li><input type='radio'  name='searchtype' value='regular' required>Regular members</li>";
echo "<li><input type='radio' name='searchtype' value='loans' required>Loans</li>";
echo "<li><input type='radio' name='searchtype' value='benefits' required>Benefits</li>";
echo "<li><input type='radio' name='searchtype' value='investment' required>Investment Ideas</li>";
echo "<li><input type='radio' name='searchtype' value='contributions' required>contributions</li>";
echo "<li><input type='radio' name='searchtype' value='members' required>All Members</li>";
echo "<li><input type='radio' name='searchtype' value='payback' required>Loan PayBack</li>";
echo "</ul>";
echo"<input type='submit' value='Search report' id='search'>";
echo "</fieldset>";
echo "</form>";
echo "</section>";

/*Footer contains Paragraph of mission statement for Family SACCO*/
echo "<footer>";
echo "<p class='foot'>We strive to raise the living standards of out members by helping them 
to save and invest their income thus improving the income status of the community</p>";
echo "</footer>";
echo "</div>";
}
 	
function createDataBase(){
  if(mysql_query("CREATE DATABASE familysacco")){
  echo "DATABASE CREATED";
  }
	//Select the database to maniplate and check if it is selected
	$db=mysql_select_db("familysacco");
	if(!$db){
	echo "Database not selected selected";	
	}
	//create table admin
	$table1=mysql_query("CREATE TABLE admin
	(
		username VARCHAR(30) NOT NULL PRIMARY KEY,
		password VARCHAR(20) NOT NULL
	  )");
	//create table members
	$table2=mysql_query("CREATE TABLE contributions
	(
		reciept_no  int unsigned NOT NULL PRIMARY KEY,
		contribution_amount  VARCHAR(30)  NOT NULL,
		contribution_date varchar(30)  NOT NULL,
		name  VARCHAR(50)  NOT NULL
		)");

     //create table members
	$table3=mysql_query("CREATE TABLE members
	(
		user_name VARCHAR(40) NOT NULL PRIMARY KEY,
		name VARCHAR(100) NOT NULL,
		password VARCHAR(80) NOT NULL,
		date_joined  VARCHAR(30) NOT NULL	
	)");
    //create table shares 
	$table4=mysql_query("CREATE TABLE shares
	(
		username  VARCHAR(40) NOT NULL PRIMARY KEY,
		share_percentage  double NOT NULL,
		total_contribution  int NOT NULL
			)");
	//create table investment_ideas		
	$table5=mysql_query("CREATE TABLE investment_ideas
	(
		idea_id int unsigned NOT NULL auto_increment PRIMARY KEY,
		idea_name VARCHAR(100) NOT NULL,
		description VARCHAR(100) NOT NULL,
		capital INT NOT NULL,
		date_started varchar(20) NOT NULL,
		member_name VARCHAR(40) NOT NULL
        )");
		//create table investment_followUp		
	$table6=mysql_query("CREATE TABLE investment_followUp
	(
		idea_id int unsigned NOT NULL,
		date_received varchar(20) NOT NULL,
		amount INT NOT NULL,
		category varchar(20) NOT NULL
        )");
		//Create table loans
		$table7=mysql_query("CREATE TABLE loans
	(
		loan_no int unsigned NOT NULL auto_increment PRIMARY KEY,
		loan_date date NOT NULL,
		loan_amount INT NOT NULL,
		monthly_repay int NOT NULL,
		total_repayment int NOT NULL,
		repayment_date varchar(20)  
        )");
		//Create table loanPayBack
		$table8=mysql_query("CREATE TABLE loanPayBack
	     (
		loan_no int unsigned NOT NULL PRIMARY KEY,
		payback_date varchar(20) NOT NULL,
		percentage_repay INT NOT NULL,
		cummulative_repay int NOT NULL,
		total_repayment int NOT NULL,
		amount int NOT NULL 
        )");
		
}

/*if ((isset($_POST['subcont'])) && ($_POST['subcont']=="accept")){
submitcont();
}else{
$lines= file('sacco.txt');
foreach($lines as $data){
if((strncmp($data,"contribution",12)==0)){
$details=explode(" ",$data);
$name=$details[3]." ".$details[4];
if ($name=$_POST['myname']){
file_put_contents('sacco.txt', str_replace($data, " ", file_get_contents('sacco.txt')));
verify();
}
}
}
}
function submitcont(){
      $name=$_POST['myname'];
      if(mysql_query("insert into contributions(reciept_no,name)
			values(1,'$name')")){
			 //values('(int)($details[5])','$details[1]','$details[2]','$name')"));{
	   echo "submited";
	   $lines= file('sacco.txt');
foreach($lines as $data){
if((strncmp($data,"contribution",12)==0)){
$details=explode(" ",$data);
$name=$details[3]." ".$details[4];
if ($name=$_POST['myname']){
file_put_contents('sacco.txt', str_replace($data, " ", file_get_contents('sacco.txt')));
}
}
}
		}else{
		echo $_POST['myname'];
		
	   }
	   verify();
	}
*/

?>